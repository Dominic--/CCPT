#include <pmm.h>
#include <list.h>
#include <string.h>
#include <default_pmm.h>

free_area_t free_area;

#define free_list (free_area.free_list)
#define nr_free (free_area.nr_free)

static void
default_init(void) {
    list_init(&free_list);
    nr_free = 0;
}

static void
default_init_memmap(struct Page *base, size_t n) {
    struct Page *p = base;
    for (; p != base + n; p ++) {
        assert(PageReserved(p));
        p->flags = 0;//p->property = 0;
        set_page_ref(p, 0);
	ClearPageProperty(p);
    }
    base->property = n;
    SetPageProperty(base);
    nr_free += n;
    list_add(list_prev(&free_list), &(base->page_link));
}

static struct Page * default_alloc_pages(size_t n) {
    if (n > nr_free) {
        return NULL;
    }
    assert(n > 0);
    struct Page *page = NULL, *p = NULL;
    list_entry_t *le = &free_list;
    while ((le = list_next(le)) != &free_list) {
        p = le2page(le, page_link);
        if (p->property >= n) {
            	page = p;
		p = page + n;
		if (page->property > n) {
		    
		    p->property = page->property - n;
		    list_add(&(page->page_link), &(p->page_link));//this one poisons me to death...
			SetPageProperty(p);
		}
		list_del(&(page->page_link));
		nr_free -= n;
		ClearPageProperty(page);
    		return page;
        }
    }
    return NULL;
}

static void
default_free_pages(struct Page *base, size_t n) {
    assert(n > 0);
    struct Page *p = base;
    for (; p != base + n; p ++) {
        assert(!PageReserved(p) && !PageProperty(p));
        p->flags = 0;
        set_page_ref(p, 0);
    }
    base->property = n;
    SetPageProperty(base);
    list_entry_t *le = list_next(&free_list);
    while (le != &free_list) {//merge two lists
        p = le2page(le, page_link);
        if (base + base->property == p) {
            base->property += p->property;
            ClearPageProperty(p);
            list_del(&(p->page_link));
//		le = &(base->page_link);	//changed
        }
        else if (p + p->property == base) {
            p->property += base->property;
            ClearPageProperty(base);
            base = p;
            list_del(&(base->page_link));	//changed
        }
        le = list_next(le);
    }

	le = list_next(&free_list);

	while (le != &free_list) {
		p = le2page(le, page_link);
		if (p > base)
			break;
		le = list_next(le);
        }
	list_add(list_prev(le), &(base->page_link));
   nr_free += n;
    
}
/*
static void
default_free_pages(struct Page *base, size_t n) {
	list_entry_t *le = &free_list, *lp = &free_list;
	base->property = n;
	while((le = list_next(le)) != &free_list) {
		struct Page* p = le2page(le, page_link);
		assert(p != base);
		if(p < base) {
			lp = le;
			if(p + p->property == base) {
				base = p;
				base->property += n;
				lp = NULL;
			}
			continue;
		}
		if(p > base) {
			if(base + base->property == p) {
				base->property += p->property;
				list_del(&(p->page_link));
				le = &(base->page_link);
			}
		}
	}
	nr_free += n;
	if(lp != NULL) {
		base->flags = 0;
		set_page_ref(base, 0);
		list_add(lp, &(base->page_link));
		SetPageProperty(base);
	}
}
*/
static size_t
default_nr_free_pages(void) {
    return nr_free;
}

static void
basic_check(void) {
    struct Page *p0, *p1, *p2;
    p0 = p1 = p2 = NULL;
    assert((p0 = alloc_page()) != NULL);
    assert((p1 = alloc_page()) != NULL);
    assert((p2 = alloc_page()) != NULL);

    assert(p0 != p1 && p0 != p2 && p1 != p2);
    assert(page_ref(p0) == 0 && page_ref(p1) == 0 && page_ref(p2) == 0);

    assert(page2pa(p0) < npage * PGSIZE);
    assert(page2pa(p1) < npage * PGSIZE);
    assert(page2pa(p2) < npage * PGSIZE);

    list_entry_t free_list_store = free_list;
    list_init(&free_list);
    assert(list_empty(&free_list));

    unsigned int nr_free_store = nr_free;
    nr_free = 0;

    assert(alloc_page() == NULL);

    free_page(p0);
    free_page(p1);
    free_page(p2);
    assert(nr_free == 3);

    assert((p0 = alloc_page()) != NULL);
    assert((p1 = alloc_page()) != NULL);
    assert((p2 = alloc_page()) != NULL);

    assert(alloc_page() == NULL);

    free_page(p0);
    assert(!list_empty(&free_list));

    struct Page *p;
    assert((p = alloc_page()) == p0);
    assert(alloc_page() == NULL);

    assert(nr_free == 0);
    free_list = free_list_store;
    nr_free = nr_free_store;

    free_page(p);
    free_page(p1);
    free_page(p2);
}


// LAB2 EXERCISE1: 2009013238
// below code is used to check the first fit allocation algorithm (SHOULD NOT CHANGE basic_check, default_check functions!)
// you should rewrite up functions: default_init,default_init_memmap,default_alloc_pages, default_free_pages
// to realize the first fit allocation algorithm
static void
default_check(void) {
    int count = 0, total = 0;
    list_entry_t *le = &free_list;
    while ((le = list_next(le)) != &free_list) {
        struct Page *p = le2page(le, page_link);
        assert(PageProperty(p));
        count ++, total += p->property;
    }
    assert(total == nr_free_pages());

    basic_check();

    struct Page *p0 = alloc_pages(5), *p1, *p2;
    assert(p0 != NULL);
    assert(!PageProperty(p0));

    list_entry_t free_list_store = free_list;
    list_init(&free_list);
    assert(list_empty(&free_list));
    assert(alloc_page() == NULL);

    unsigned int nr_free_store = nr_free;
    nr_free = 0;

    free_pages(p0 + 2, 3);
    assert(alloc_pages(4) == NULL);
    assert(PageProperty(p0 + 2) && p0[2].property == 3);
    assert((p1 = alloc_pages(3)) != NULL);
    assert(alloc_page() == NULL);
    assert(p0 + 2 == p1);

    p2 = p0 + 1;
    free_page(p0);
    free_pages(p1, 3);
    assert(PageProperty(p0) && p0->property == 1);
    assert(PageProperty(p1) && p1->property == 3);

    assert((p0 = alloc_page()) == p2 - 1);
    free_page(p0);
    assert((p0 = alloc_pages(2)) == p2 + 1);

    free_pages(p0, 2);
    free_page(p2);

    assert((p0 = alloc_pages(5)) != NULL);
    assert(alloc_page() == NULL);

    assert(nr_free == 0);
    nr_free = nr_free_store;

    free_list = free_list_store;
    free_pages(p0, 5);

    le = &free_list;
    while ((le = list_next(le)) != &free_list) {
        struct Page *p = le2page(le, page_link);
        count --, total -= p->property;
    }
    assert(count == 0);
    assert(total == 0);
}

const struct pmm_manager default_pmm_manager = {
    .name = "default_pmm_manager",
    .init = default_init,
    .init_memmap = default_init_memmap,
    .alloc_pages = default_alloc_pages,
    .free_pages = default_free_pages,
    .nr_free_pages = default_nr_free_pages,
    .check = default_check,
};

