#ifndef __KERN_SYNC_CONDVAR_H__
#define __KERN_SYNC_CONDVAR_H__

#include <sem.h>

typedef struct {
	unsigned int waiters;   // the number of waiters
	unsigned int signals;   // the number of signals
	semaphore_t mutex;      // the mutex lock for going into monitor, should be initialized to 1
	semaphore_t next;       // the next semaphore is used to down the signaling proc itself, and the wakeuped waiting proc should up the signaling proc.
	semaphore_t sem;        // the sem semaphore  is used to down the waiting proc, and the signaling proc should up the waiting proc
} condvar_t;
// Initialize condition variable. 
void 	cond_init (condvar_t *cvp);
// Unlock one of threads waiting on the condition variable. 
void 	cond_signal (condvar_t *cvp);
// Suspend calling thread on a condition variable waiting for condition Atomically unlocks 
// mutex and suspends calling thread on conditional variable after waking up locks mutex. Notice: mp is mutex semaphore for monitor's procedures
void 	cond_wait (condvar_t *cvp, semaphore_t *mp);
 	
#endif /* !__KERN_SYNC_CONDVAR_H__ */
