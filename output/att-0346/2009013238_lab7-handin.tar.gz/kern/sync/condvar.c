#include <condvar.h>

// Initialize condition variable. 
void 	
cond_init (condvar_t *cvp) {
	cvp->waiters=0;
	cvp->signals=0;
	sem_init(&(cvp->mutex), 1); //unlocked
	sem_init(&(cvp->sem), 0);
	sem_init(&(cvp->next), 0);
}

// Unlock one of threads waiting on the condition variable. 
void 
cond_signal (condvar_t *cvp) {
	//cprintf("cond_signal begin: cvp %x, cvp->waiters %d, cvp->signals %d\n", cvp, cvp->waiters, cvp->signals);

	//LAB7 EXERCISE1: 2009013238
	down(&cvp->mutex);
	if(cvp->waiters > 0) 
	{
		cvp->signals++;
		up(&cvp->sem);
		up(&cvp->mutex);
		down(&cvp->next);
		down(&cvp->mutex);
		cvp->signals--;
	}
	up(&cvp->mutex);
	//LAB7 EXERCISE1: 2009013238

	//cprintf("cond_signal end: cvp %x, cvp->waiters %d, cvp->signals %d\n",cvp, cvp->waiters, cvp->signals);
}

// Suspend calling thread on a condition variable waiting for condition Atomically unlocks 
// mutex and suspends calling thread on conditional variable after waking up locks mutex. Notice: mp is mutex semaphore for monitor's procedures
void
cond_wait (condvar_t *cvp, semaphore_t *mp) {
	//cprintf("cond_wait begin:  cvp %x, cvp->waiters %d, cvp->signals %d\n", cvp, cvp->waiters, cvp->signals);

	//LAB7 EXERCISE1: 2009013238
	down(&cvp->mutex);
	cvp->waiters++;
	if(cvp->signals > 0) 
		up(&cvp->next);
	else 
		up(mp);
	
	up(&cvp->mutex);
	down(&cvp->sem);
	down(&cvp->mutex);
	cvp->waiters--;
	up(&cvp->mutex);
	//LAB7 EXERCISE1: 2009013238

	//cprintf("cond_wait end:  cvp %x, cvp->waiters %d, cvp->signals %d\n", cvp, cvp->waiters, cvp->signals);
}
